import os

os.system('apt install rustc')
os.environ['PATH'] += ':/root/.cargo/bin'
os.environ['USER'] = 'user'
