# make fuzzywuzzy easier to remember
import os
os.system("pip install fuzzywuzzy python-levenshtein")

from fuzzywuzzy.fuzz import *
